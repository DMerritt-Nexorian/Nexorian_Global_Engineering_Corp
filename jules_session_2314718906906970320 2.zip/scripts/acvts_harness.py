import os
import time
import hmac
import hashlib
import struct
import base64
import requests

# Filesystem layout
CERT_PATH = "certs/client.crt"
KEY_PATH = "certs/client.key"
TOTP_KEY_PATH = "certs/totp.key"
ACVTS_URL = "https://demo.acvts.nist.gov/acvp/v1/"

def generate_totp(secret_base64: str) -> str:
    """Generates a standard 6-digit TOTP token using the provided key."""
    key = base64.b64decode(secret_base64) if len(secret_base64) % 4 == 0 and "=" in secret_base64 else secret_base64.encode('utf-8')
    time_counter = int(time.time() // 30)
    msg = struct.pack(">Q", time_counter)
    hmac_digest = hmac.new(key, msg, hashlib.sha256).digest()
    offset = hmac_digest[-1] & 0x0F
    code = ((hmac_digest[offset] & 0x7F) << 24 |
            (hmac_digest[offset+1] & 0xFF) << 16 |
            (hmac_digest[offset+2] & 0xFF) << 8 |
            (hmac_digest[offset+3] & 0xFF)) % 1000000
    return f"{code:06d}"

def execute_acvts_login():
    """Authenticates against NIST ACVTS Demo Endpoint using mTLS + TOTP."""
    if not os.path.exists(CERT_PATH) or not os.path.exists(KEY_PATH):
        print(f"[-] Missing mTLS key pair in ./certs directory.")
        return False

    if not os.path.exists(TOTP_KEY_PATH):
        print(f"[-] Missing TOTP key file at {TOTP_KEY_PATH}.")
        return False

    with open(TOTP_KEY_PATH, "r") as f:
        totp_secret = f.read().strip()

    totp_pin = generate_totp(totp_secret)
    print(f"[*] Generated TOTP Pin: {totp_pin}")

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {totp_pin}"
    }

    print(f"[*] Initiating mTLS connection to {ACVTS_URL}...")
    session = requests.Session()
    session.cert = (CERT_PATH, KEY_PATH)
    
    try:
        response = session.get(ACVTS_URL, headers=headers, timeout=10)
        print(f"[+] Status Code: {response.status_code}")
        print(f"[+] Response Body:\n{response.text}")
        return response.status_code == 200
    except Exception as e:
        print(f"[-] Connection failed: {e}")
        return False

if __name__ == "__main__":
    success = execute_acvts_login()
    exit(0 if success else 1)
